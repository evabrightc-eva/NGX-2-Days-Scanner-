
import pandas as pd
from scanner.regime import calculate_regime

def test_bullish_regime():
    dates = pd.date_range("2026-01-01", periods=25)
    prices = []
    for d in dates:
        prices += [
            {"date":d,"symbol":"A","close":100+(d.day)},
            {"date":d,"symbol":"B","close":100+(d.day)*0.8},
            {"date":d,"symbol":"C","close":100+(d.day)*0.6},
        ]
    p = pd.DataFrame(prices)
    idx = pd.DataFrame({"date":dates,"symbol":["ASI"]*25,"close":[100+i for i in range(25)]})
    cfg = {"regime":{"asi_symbol":"ASI","breadth_bullish_pct":0.55,"breadth_bearish_pct":0.45,
                     "asi_bullish_5d":0.01,"asi_bearish_5d":-0.01}}
    x=calculate_regime(p,idx,cfg)
    assert x["regime"] == "BULLISH"
