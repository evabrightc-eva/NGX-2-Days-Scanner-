import pandas as pd
from scanner.indicators import add_indicators

def test_indicators():
    n = 100
    df = pd.DataFrame({
        "date": pd.date_range("2026-01-01", periods=n),
        "symbol": ["TEST"]*n,
        "open": range(100, 100+n),
        "high": range(101, 101+n),
        "low": range(99, 99+n),
        "close": range(100, 100+n),
        "volume": [100000]*n
    })
    out = add_indicators(df)
    assert "rsi14" in out
    assert "macd" in out
    assert out["sma20"].notna().sum() > 70
