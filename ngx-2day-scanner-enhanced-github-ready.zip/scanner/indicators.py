import numpy as np
import pandas as pd

def ema(s, span):
    return s.ewm(span=span, adjust=False).mean()

def rsi(close, period=14):
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1/period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    out = 100 - (100 / (1 + rs))
    return out.fillna(50)

def atr(df, period=14):
    prev = df["close"].shift(1)
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev).abs(),
        (df["low"] - prev).abs()
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def add_indicators(df):
    df = df.sort_values("date").copy()
    c = df["close"]
    v = df["volume"]

    df["ret_1d"] = c.pct_change(1)
    df["ret_5d"] = c.pct_change(5)
    df["ret_20d"] = c.pct_change(20)

    df["sma5"] = c.rolling(5).mean()
    df["sma20"] = c.rolling(20).mean()
    df["sma50"] = c.rolling(50).mean()

    df["ema12"] = ema(c, 12)
    df["ema26"] = ema(c, 26)
    df["macd"] = df["ema12"] - df["ema26"]
    df["macd_signal"] = ema(df["macd"], 9)
    df["macd_hist"] = df["macd"] - df["macd_signal"]

    df["rsi14"] = rsi(c, 14)
    df["atr14"] = atr(df, 14)

    df["avg_volume20"] = v.rolling(20).mean()
    df["volume_ratio"] = v / df["avg_volume20"].replace(0, np.nan)
    df["turnover"] = c * v
    df["avg_turnover20"] = df["turnover"].rolling(20).mean()

    df["high20"] = df["high"].rolling(20).max().shift(1)
    df["low20"] = df["low"].rolling(20).min().shift(1)

    df["distance_resistance"] = (df["high20"] - c) / c
    df["above_sma20"] = c > df["sma20"]
    df["above_sma50"] = c > df["sma50"]
    df["breakout20"] = c > df["high20"]

    return df
