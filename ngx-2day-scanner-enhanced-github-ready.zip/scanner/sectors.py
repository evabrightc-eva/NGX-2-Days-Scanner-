import pandas as pd
import numpy as np

def sector_metrics(results):
    if results.empty or "sector" not in results:
        return pd.DataFrame(columns=["sector","sector_score","sector_return_5d","sector_breadth"])
    rows = []
    for sector, g in results.groupby("sector"):
        valid = g.dropna(subset=["ret_5d"])
        ret = valid["ret_5d"].mean() if not valid.empty else 0
        breadth = (valid["ret_5d"] > 0).mean() if not valid.empty else 0.5
        score = max(0, min(100, 50 + ret*400 + (breadth-0.5)*50))
        rows.append({
            "sector":sector,
            "sector_score":round(score,2),
            "sector_return_5d":round(ret*100,2),
            "sector_breadth":round(breadth,3)
        })
    return pd.DataFrame(rows)

def apply_sector_limits(results, cfg):
    if results.empty:
        return results
    sm = sector_metrics(results)
    out = results.merge(sm, on="sector", how="left")
    out["sector_score"] = out["sector_score"].fillna(50)

    # Sector strength is a filter, not a ranking across political or other non-market criteria.
    out.loc[
        (out["signal"] == "STRONG BUY") &
        (out["sector_score"] < cfg["min_sector_score"]),
        "signal"
    ] = "WATCH"

    # Limit concentration after scoring.
    count = {}
    for idx, row in out.sort_values("score", ascending=False).iterrows():
        if row["signal"] == "STRONG BUY":
            sec = row["sector"]
            count[sec] = count.get(sec, 0) + 1
            if count[sec] > cfg["max_strong_buys_per_sector"]:
                out.at[idx, "signal"] = "BUY"

    return out
