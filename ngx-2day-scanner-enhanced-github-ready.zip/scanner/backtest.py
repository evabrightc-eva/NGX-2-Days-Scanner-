from pathlib import Path
import yaml
import pandas as pd
import numpy as np

from .data_ngx import load_csv_directory
from .indicators import add_indicators
from .fundamentals import load_fundamentals, fundamental_score
from .scoring import score_row

def run_backtest(config_path="config.yaml"):
    cfg_path = Path(config_path)
    if not cfg_path.exists():
        cfg_path = Path("config.example.yaml")
    cfg = yaml.safe_load(cfg_path.read_text())

    prices = load_csv_directory(cfg["data"]["price_dir"])
    funds = load_fundamentals(cfg["data"]["fundamentals_file"])
    if prices.empty:
        raise SystemExit("No CSV price history available for backtest.")

    trades = []
    for symbol, raw in prices.groupby("symbol"):
        raw = raw.sort_values("date").reset_index(drop=True)
        if len(raw) < cfg["scanner"]["min_history_days"] + 3:
            continue
        for i in range(cfg["scanner"]["min_history_days"], len(raw)-2):
            hist = raw.iloc[:i+1].copy()
            ind = add_indicators(hist)
            r = ind.iloc[-1].to_dict()
            frow = funds[funds["symbol"] == symbol]
            fs = fundamental_score(frow.iloc[0].to_dict()) if not frow.empty else 50
            s = score_row(r, fs, cfg["scanner"], cfg["weights"])
            if s["signal"] != "STRONG BUY":
                continue

            entry = float(r["close"])
            target = float(s["target_price"])
            stop = entry * (1 - cfg["scanner"]["stop_pct"])
            future = raw.iloc[i+1:i+3]
            hit_target = bool((future["high"] >= target).any())
            hit_stop = bool((future["low"] <= stop).any())

            if hit_target and hit_stop:
                # Conservative same-window assumption.
                outcome = "STOP"
                exit_price = stop
            elif hit_target:
                outcome = "TARGET"
                exit_price = target
            elif hit_stop:
                outcome = "STOP"
                exit_price = stop
            else:
                outcome = "EXPIRED"
                exit_price = float(future.iloc[-1]["close"])

            trades.append({
                "symbol":symbol, "date":str(r["date"].date()),
                "entry":entry, "target":target, "stop":stop,
                "outcome":outcome,
                "return_pct":(exit_price/entry-1)*100
            })

    df = pd.DataFrame(trades)
    Path("reports").mkdir(exist_ok=True)
    df.to_csv("reports/backtest_trades.csv", index=False)

    if df.empty:
        print("No historical Strong Buy signals found.")
        return

    wins = df[df["return_pct"] > 0]
    losses = df[df["return_pct"] < 0]
    profit_factor = wins["return_pct"].sum() / abs(losses["return_pct"].sum()) if not losses.empty else np.inf

    summary = pd.DataFrame([{
        "signals":len(df),
        "target_hit_rate":round((df["outcome"]=="TARGET").mean()*100,2),
        "stop_hit_rate":round((df["outcome"]=="STOP").mean()*100,2),
        "expired_rate":round((df["outcome"]=="EXPIRED").mean()*100,2),
        "avg_return_pct":round(df["return_pct"].mean(),2),
        "avg_winner_pct":round(wins["return_pct"].mean(),2) if not wins.empty else 0,
        "avg_loser_pct":round(losses["return_pct"].mean(),2) if not losses.empty else 0,
        "profit_factor":round(profit_factor,2) if np.isfinite(profit_factor) else "inf"
    }])
    summary.to_csv("reports/performance.csv", index=False)
    print(summary.to_string(index=False))

if __name__ == "__main__":
    run_backtest()
