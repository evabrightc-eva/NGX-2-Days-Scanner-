import math
import numpy as np
import pandas as pd

def clamp(x, lo=0, hi=100):
    return max(lo, min(hi, float(x)))

def score_momentum(r):
    s = 50
    s += clamp(r.get("ret_5d", 0) * 400, -20, 20)
    s += clamp(r.get("ret_20d", 0) * 150, -15, 15)
    if r.get("above_sma20", False): s += 8
    if r.get("above_sma50", False): s += 5
    if r.get("macd_hist", 0) > 0: s += 7
    if r.get("breakout20", False): s += 10
    rsi = r.get("rsi14", 50)
    if 52 <= rsi <= 68: s += 8
    elif 68 < rsi <= 72: s += 4
    elif rsi > 82: s -= 20
    elif rsi < 40: s -= 10
    return clamp(s)

def score_volume(r):
    s = 50
    vr = r.get("volume_ratio", 1)
    if vr >= 2: s += 25
    elif vr >= 1.5: s += 18
    elif vr >= 1.2: s += 10
    elif vr < 0.7: s -= 15
    if r.get("ret_1d", 0) > 0 and vr >= 1.2: s += 12
    if r.get("breakout20", False) and vr >= 1.2: s += 10
    return clamp(s)

def score_risk(r, cfg):
    s = 70
    rsi = r.get("rsi14", 50)
    if rsi > cfg["max_rsi_hard"]: s -= 35
    elif rsi > cfg["max_rsi_for_full_score"]: s -= 12
    dist = r.get("distance_resistance", np.nan)
    if not pd.isna(dist) and dist < -cfg["resistance_buffer"]: s -= 15
    atr = r.get("atr14", np.nan)
    close = r.get("close", np.nan)
    if not pd.isna(atr) and close:
        atr_pct = atr / close
        if atr_pct > 0.12: s -= 20
        elif atr_pct > 0.08: s -= 8
    return clamp(s)

def estimate_target(r, cfg):
    close = float(r["close"])
    ret5 = float(r.get("ret_5d", 0) or 0)
    ret20 = float(r.get("ret_20d", 0) or 0)
    vr = float(r.get("volume_ratio", 1) or 1)

    # A conservative blended momentum projection, capped by configured 5-10% target.
    raw = 0.45 * (ret5 / 2) + 0.35 * (ret20 / 4) + 0.20 * max(ret5, 0)
    if vr >= 1.5:
        raw += 0.01
    raw = max(cfg["target_min"], min(cfg["target_max"], raw))
    return close * (1 + raw), raw

def classify(score, target_return, eligible, cfg):
    if not eligible:
        return "WATCH"
    if score >= cfg["strong_buy_score"] and cfg["target_min"] <= target_return <= cfg["target_max"]:
        return "STRONG BUY"
    if score >= cfg["buy_score"]:
        return "BUY"
    return "WATCH"

def build_reasons(r, scores):
    reasons = []
    if r.get("breakout20", False): reasons.append("20-day breakout")
    if r.get("volume_ratio", 0) >= 1.5: reasons.append("volume surge")
    if r.get("above_sma20", False): reasons.append("above 20-day trend")
    if r.get("above_sma50", False): reasons.append("above 50-day trend")
    if r.get("macd_hist", 0) > 0: reasons.append("positive MACD histogram")
    if 52 <= r.get("rsi14", 50) <= 72: reasons.append("supportive RSI")
    if scores["fundamentals"] >= 65: reasons.append("fundamentals supportive")
    if scores["risk"] < 55: reasons.append("elevated risk")
    return reasons[:6]

def score_row(r, fund_score, cfg, weights):
    m = score_momentum(r)
    v = score_volume(r)
    f = fund_score
    risk = score_risk(r, cfg)
    total = weights["momentum"]*m + weights["volume"]*v + weights["fundamentals"]*f + weights["risk"]*risk
    target_price, target_return = estimate_target(r, cfg)

    eligible = (
        r["close"] >= cfg["min_price"]
        and r["avg_turnover20"] >= cfg["min_avg_turnover_20"]
        and not pd.isna(r["rsi14"])
        and not pd.isna(r["sma20"])
        and rsi_ok(r, cfg)
    )
    signal = classify(total, target_return, eligible, cfg)
    return {
        "momentum": round(m,2),
        "volume": round(v,2),
        "fundamentals": round(f,2),
        "risk": round(risk,2),
        "score": round(total,2),
        "target_price": round(target_price,2),
        "target_return": round(target_return*100,2),
        "signal": signal,
        "reasons": build_reasons(r, {"fundamentals":f,"risk":risk})
    }

def rsi_ok(r, cfg):
    return float(r.get("rsi14", 50)) <= cfg["max_rsi_hard"]
