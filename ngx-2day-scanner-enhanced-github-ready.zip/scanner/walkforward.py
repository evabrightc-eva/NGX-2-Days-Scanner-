from pathlib import Path
import yaml
import numpy as np
import pandas as pd

from .data_ngx import load_csv_directory
from .indicators import add_indicators
from .fundamentals import load_fundamentals, fundamental_score
from .scoring import score_row

def _evaluate_signal(raw, i, cfg, funds):
    hist = raw.iloc[:i+1].copy()
    ind = add_indicators(hist)
    r = ind.iloc[-1].to_dict()
    frow = funds[funds["symbol"] == raw.iloc[i]["symbol"]]
    fs = fundamental_score(frow.iloc[0].to_dict()) if not frow.empty else 50
    s = score_row(r, fs, cfg["scanner"], cfg["weights"])
    if s["signal"] != "STRONG BUY":
        return None

    future = raw.iloc[i+1:i+3]
    if len(future) < 2:
        return None
    entry = float(r["close"])
    target = float(s["target_price"])
    stop = entry * (1-cfg["scanner"]["stop_pct"])

    hit_target = bool((future["high"] >= target).any())
    hit_stop = bool((future["low"] <= stop).any())

    if hit_target and hit_stop:
        exit_price = stop
        outcome = "STOP"
    elif hit_target:
        exit_price = target
        outcome = "TARGET"
    elif hit_stop:
        exit_price = stop
        outcome = "STOP"
    else:
        exit_price = float(future.iloc[-1]["close"])
        outcome = "EXPIRED"

    return {
        "symbol": raw.iloc[i]["symbol"],
        "signal_date": str(raw.iloc[i]["date"].date()),
        "entry":entry,
        "exit":exit_price,
        "return_pct":(exit_price/entry-1)*100,
        "outcome":outcome
    }

def walk_forward(config_path="config.yaml"):
    cfg_path = Path(config_path)
    if not cfg_path.exists():
        cfg_path = Path("config.example.yaml")
    cfg = yaml.safe_load(cfg_path.read_text())
    prices = load_csv_directory(cfg["data"]["price_dir"])
    funds = load_fundamentals(cfg["data"]["fundamentals_file"])
    if prices.empty:
        raise SystemExit("No CSV price history for walk-forward test.")

    train = cfg["backtest"]["train_days"]
    test = cfg["backtest"]["test_days"]
    step = cfg["backtest"]["step_days"]
    rows = []

    for symbol, raw in prices.groupby("symbol"):
        raw = raw.sort_values("date").reset_index(drop=True)
        start = train
        while start + test + 2 <= len(raw):
            test_end = min(start + test, len(raw)-2)
            for i in range(start, test_end):
                x = _evaluate_signal(raw, i, cfg, funds)
                if x:
                    x["window_train_end"] = str(raw.iloc[start-1]["date"].date())
                    x["window_test_end"] = str(raw.iloc[test_end-1]["date"].date())
                    rows.append(x)
            start += step

    out = pd.DataFrame(rows)
    Path("reports").mkdir(exist_ok=True)
    out.to_csv("reports/walkforward_trades.csv", index=False)

    if out.empty:
        summary = pd.DataFrame([{"signals":0,"message":"No Strong Buy signals in walk-forward test."}])
    else:
        wins = out[out.return_pct > 0]
        losses = out[out.return_pct < 0]
        pf = wins.return_pct.sum()/abs(losses.return_pct.sum()) if not losses.empty else np.inf
        summary = pd.DataFrame([{
            "signals":len(out),
            "target_hit_rate_pct":round((out.outcome=="TARGET").mean()*100,2),
            "stop_hit_rate_pct":round((out.outcome=="STOP").mean()*100,2),
            "expired_rate_pct":round((out.outcome=="EXPIRED").mean()*100,2),
            "avg_return_pct":round(out.return_pct.mean(),2),
            "median_return_pct":round(out.return_pct.median(),2),
            "profit_factor":round(pf,2) if np.isfinite(pf) else "inf"
        }])
    summary.to_csv("reports/walkforward_summary.csv", index=False)
    print(summary.to_string(index=False))
    return summary

if __name__ == "__main__":
    walk_forward()
