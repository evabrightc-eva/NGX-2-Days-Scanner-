import argparse
from pathlib import Path
import yaml
import pandas as pd

from .data_ngx import get_prices
from .fundamentals import load_fundamentals, fundamental_score
from .indicators import add_indicators
from .scoring import score_row
from .report import write_reports
from .regime import load_index_history, calculate_regime, regime_score
from .sectors import apply_sector_limits
from .telegram import send_message, build_alert

def load_config(path="config.yaml"):
    p = Path(path)
    if not p.exists():
        p = Path("config.example.yaml")
    return yaml.safe_load(p.read_text())

def run(mode="primary", config_path="config.yaml"):
    cfg = load_config(config_path)
    prices = get_prices(cfg)
    if prices.empty:
        raise SystemExit("No price data available. Configure NGX_API_TOKEN or add CSV data.")

    fundamentals = load_fundamentals(cfg["data"]["fundamentals_file"])
    index_df = load_index_history(cfg["data"]["index_file"])
    regime = calculate_regime(prices, index_df, cfg)

    rows = []
    for symbol, g in prices.groupby("symbol"):
        g = g.sort_values("date").tail(cfg["data"]["lookback_days"]).copy()
        if len(g) < cfg["scanner"]["min_history_days"]:
            continue
        g = add_indicators(g)
        r = g.iloc[-1].to_dict()
        frow = fundamentals[fundamentals["symbol"] == symbol]
        fd = frow.iloc[0].to_dict() if not frow.empty else {}
        fund_score = fundamental_score(fd) if fd else 50.0

        result = score_row(r, fund_score, cfg["scanner"], cfg["weights"])
        # Market-cap eligibility
        mcap = fd.get("market_cap")
        if mcap is not None and pd.notna(mcap):
            if mcap < cfg["scanner"]["min_market_cap"]:
                result["signal"] = "WATCH"
            if cfg["scanner"]["max_market_cap"] is not None and mcap > cfg["scanner"]["max_market_cap"]:
                result["signal"] = "WATCH"

        result["regime_score"] = regime_score(regime)
        result["regime"] = regime["regime"]

        # Strong Buy requires a non-bearish market regime when enabled.
        if (
            result["signal"] == "STRONG BUY"
            and cfg["scanner"]["require_positive_regime_for_strong_buy"]
            and regime["regime"] not in cfg["scanner"]["allowed_regimes"]
        ):
            result["signal"] = "WATCH"

        result.update({
            "date": str(r["date"].date()),
            "symbol": symbol,
            "sector": fd.get("sector", "Unknown"),
            "market_cap": fd.get("market_cap", None),
            "close": float(r["close"]),
            "volume": float(r["volume"]),
            "rsi14": float(r["rsi14"]),
            "volume_ratio": float(r["volume_ratio"]) if pd.notna(r["volume_ratio"]) else 0,
            "ret_1d": float(r["ret_1d"]) if pd.notna(r["ret_1d"]) else 0,
            "ret_5d": float(r["ret_5d"]) if pd.notna(r["ret_5d"]) else 0,
            "ret_20d": float(r["ret_20d"]) if pd.notna(r["ret_20d"]) else 0,
            "avg_turnover20": float(r["avg_turnover20"]),
        })
        rows.append(result)

    out = pd.DataFrame(rows)
    if not out.empty:
        out = apply_sector_limits(out, cfg["scanner"])
        rank = {"STRONG BUY":0,"BUY":1,"WATCH":2}
        out["_rank"] = out["signal"].map(rank).fillna(9)
        out = out.sort_values(["_rank","score"], ascending=[True,False]).drop(columns="_rank")

    write_reports(out, mode)

    Path("reports").mkdir(exist_ok=True)
    Path("reports/regime.json").write_text(
        __import__("json").dumps(regime, indent=2), encoding="utf-8"
    )
    if not out.empty:
        out.to_csv("reports/latest.csv", index=False)

    if cfg.get("telegram", {}).get("enabled", True):
        if (not cfg["telegram"]["send_only_strong_buy"]) or out["signal"].isin(["STRONG BUY","CONFIRMED"]).any():
            try:
                send_message(build_alert(out, regime))
            except Exception as e:
                print(f"Telegram delivery failed: {e}")

    print("REGIME:", regime)
    print(out.head(20).to_string(index=False))
    return out

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="primary", choices=["primary","confirm","intraday"])
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()
    run(args.mode, args.config)
