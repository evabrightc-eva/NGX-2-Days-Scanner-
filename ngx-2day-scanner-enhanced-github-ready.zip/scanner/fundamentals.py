from pathlib import Path
import numpy as np
import pandas as pd

NUMERIC = [
    "market_cap","pe","pb","roe","revenue_growth","earnings_growth",
    "gross_margin","net_margin","current_ratio","debt_to_equity","dividend_yield"
]

def load_fundamentals(path):
    p = Path(path)
    if not p.exists():
        return pd.DataFrame(columns=["symbol"])
    df = pd.read_csv(p)
    df.columns = [c.strip().lower() for c in df.columns]
    if "symbol" not in df.columns:
        return pd.DataFrame(columns=["symbol"])
    for c in NUMERIC:
        if c in df:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df["symbol"] = df["symbol"].astype(str).str.upper().str.strip()
    return df.drop_duplicates("symbol")

def fundamental_score(row):
    checks = []
    def add(value, points):
        if value is not None and not pd.isna(value):
            checks.append(points)

    pe = row.get("pe", np.nan)
    pb = row.get("pb", np.nan)
    roe = row.get("roe", np.nan)
    rg = row.get("revenue_growth", np.nan)
    eg = row.get("earnings_growth", np.nan)
    gm = row.get("gross_margin", np.nan)
    nm = row.get("net_margin", np.nan)
    cr = row.get("current_ratio", np.nan)
    de = row.get("debt_to_equity", np.nan)

    score = 50.0
    if not pd.isna(pe):
        score += 10 if 0 < pe <= 10 else 5 if pe <= 15 else -5 if pe > 30 else 0
    if not pd.isna(pb):
        score += 6 if pb <= 1.5 else 3 if pb <= 3 else -4 if pb > 6 else 0
    if not pd.isna(roe):
        score += 8 if roe >= 20 else 4 if roe >= 12 else -4 if roe < 5 else 0
    if not pd.isna(rg):
        score += 6 if rg >= 15 else 3 if rg >= 5 else -4 if rg < 0 else 0
    if not pd.isna(eg):
        score += 8 if eg >= 20 else 4 if eg >= 5 else -6 if eg < 0 else 0
    if not pd.isna(gm):
        score += 3 if gm >= 30 else -2 if gm < 10 else 0
    if not pd.isna(nm):
        score += 4 if nm >= 10 else -3 if nm < 0 else 0
    if not pd.isna(cr):
        score += 4 if cr >= 1.5 else -4 if cr < 1 else 0
    if not pd.isna(de):
        score += 4 if de <= 0.5 else -5 if de > 2 else 0

    return float(max(0, min(100, score)))
