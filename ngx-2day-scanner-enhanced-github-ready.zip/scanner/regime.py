import pandas as pd
import numpy as np

def load_index_history(path):
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        return pd.DataFrame(columns=["date","symbol","close"])
    df.columns = [c.strip().lower() for c in df.columns]
    if not {"date","symbol","close"}.issubset(df.columns):
        return pd.DataFrame(columns=["date","symbol","close"])
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df["close"] = pd.to_numeric(df["close"], errors="coerce")
    df["symbol"] = df["symbol"].astype(str).str.upper().str.strip()
    return df.dropna(subset=["date","close"])

def _breadth(price_df, current_date):
    day = price_df[price_df["date"] == current_date].copy()
    if day.empty:
        return {"advancers":0,"decliners":0,"unchanged":0,"breadth":0.5}
    day = day.sort_values(["symbol","date"])
    prev = price_df[price_df["date"] < current_date].sort_values(["symbol","date"]).groupby("symbol").tail(1)
    merged = day.merge(prev[["symbol","close"]], on="symbol", suffixes=("_today","_prev"))
    if merged.empty:
        return {"advancers":0,"decliners":0,"unchanged":0,"breadth":0.5}
    ch = merged["close_today"] - merged["close_prev"]
    adv = int((ch > 0).sum())
    dec = int((ch < 0).sum())
    unc = int((ch == 0).sum())
    total = adv + dec
    return {
        "advancers":adv,
        "decliners":dec,
        "unchanged":unc,
        "breadth": adv/total if total else 0.5
    }

def calculate_regime(price_df, index_df, cfg):
    if price_df.empty:
        return {"regime":"UNKNOWN","score":0,"breadth":0.5,"asi_ret_5d":0,"reason":"No price data"}

    date = price_df["date"].max()
    b = _breadth(price_df, date)

    asi = index_df[index_df["symbol"] == cfg["regime"]["asi_symbol"]].sort_values("date")
    asi_ret5 = 0.0
    asi_above20 = False
    if len(asi) >= 20:
        c = asi["close"]
        asi_ret5 = float(c.iloc[-1]/c.iloc[-6]-1) if len(c) >= 6 else 0
        asi_sma20 = c.rolling(20).mean().iloc[-1]
        asi_above20 = bool(c.iloc[-1] > asi_sma20)

    score = 50.0
    score += (b["breadth"] - 0.5) * 100
    score += max(-15, min(15, asi_ret5 * 1000))
    if asi_above20:
        score += 10
    else:
        score -= 10
    score = max(0, min(100, score))

    if b["breadth"] >= cfg["regime"]["breadth_bullish_pct"] and asi_ret5 >= cfg["regime"]["asi_bullish_5d"]:
        regime = "BULLISH"
    elif b["breadth"] <= cfg["regime"]["breadth_bearish_pct"] and asi_ret5 <= cfg["regime"]["asi_bearish_5d"]:
        regime = "BEARISH"
    else:
        regime = "NEUTRAL"

    return {
        "date": str(date.date()),
        "regime": regime,
        "score": round(score,2),
        "breadth": round(b["breadth"],4),
        "advancers": b["advancers"],
        "decliners": b["decliners"],
        "unchanged": b["unchanged"],
        "asi_ret_5d": round(asi_ret5*100,2),
        "asi_above_sma20": asi_above20,
        "reason": f"{b['advancers']} advancers / {b['decliners']} decliners; ASI 5d {asi_ret5*100:.2f}%"
    }

def regime_score(regime_info):
    r = regime_info["regime"]
    if r == "BULLISH": return 90
    if r == "NEUTRAL": return 55
    if r == "BEARISH": return 20
    return 40
