from pathlib import Path
import json
import pandas as pd
from datetime import datetime

def write_reports(results, mode, report_dir="reports"):
    Path(report_dir).mkdir(parents=True, exist_ok=True)
    if results.empty:
        results = pd.DataFrame(columns=["symbol","close","signal","score","target_price","target_return"])
    results.to_csv(Path(report_dir)/"latest.csv", index=False)
    payload = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "mode": mode,
        "signals": results.to_dict(orient="records")
    }
    (Path(report_dir)/"latest.json").write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")

    lines = [
        "# NGX 2-Day Scanner",
        "",
        f"Generated: {payload['generated_at']}",
        f"Mode: **{mode}**",
        "",
        "## Strong Buy candidates",
        ""
    ]
    strong = results[results["signal"].isin(["STRONG BUY","CONFIRMED"])] if "signal" in results else results.iloc[0:0]
    if strong.empty:
        lines.append("**No Strong Buy signal met all filters.**")
    else:
        for _, r in strong.head(15).iterrows():
            lines += [
                f"### {r['symbol']} — {r['signal']}",
                f"- Score: **{r['score']} / 100**",
                f"- Close: ₦{r['close']:.2f}",
                f"- Target: ₦{r['target_price']:.2f}",
                f"- Estimated upside: **{r['target_return']:.2f}%**",
                f"- Momentum: {r['momentum']:.1f}",
                f"- Volume: {r['volume']:.1f}",
                f"- Fundamentals: {r['fundamentals']:.1f}",
                f"- Risk: {r['risk']:.1f}",
                f"- Reasons: {', '.join(r['reasons'])}",
                ""
            ]

    lines += ["## Other candidates", ""]
    others = results[~results["signal"].isin(["STRONG BUY","CONFIRMED"])] if "signal" in results else results
    for _, r in others.head(15).iterrows():
        lines.append(f"- **{r['symbol']}** — {r['signal']} — score {r['score']:.1f} — upside {r['target_return']:.2f}%")

    (Path(report_dir)/"latest.md").write_text("\n".join(lines), encoding="utf-8")
