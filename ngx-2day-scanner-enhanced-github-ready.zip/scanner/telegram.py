import os
import requests

def _escape(text):
    # Telegram MarkdownV2 escaping.
    chars = r"_*[]()~`>#+-=|{}.!"
    for c in chars:
        text = text.replace(c, "\\" + c)
    return text

def send_message(text):
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        print("Telegram not configured; skipping.")
        return False

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "MarkdownV2",
        "disable_web_page_preview": True
    }
    r = requests.post(url, json=payload, timeout=20)
    r.raise_for_status()
    return True

def build_alert(results, regime):
    strong = results[results["signal"].isin(["STRONG BUY","CONFIRMED"])]
    lines = [
        "📊 *NGX 2\\-DAY SCANNER*",
        f"Regime: *{_escape(regime['regime'])}*",
        f"ASI 5D: *{_escape(str(regime['asi_ret_5d']))}%*",
        f"Breadth: *{_escape(str(round(regime['breadth']*100,1)))}% advancers*",
        f"Advancers/Decliners: *{regime['advancers']}/{regime['decliners']}*",
        ""
    ]
    if strong.empty:
        lines.append("No Strong Buy signal met all filters today.")
    else:
        for _, r in strong.head(10).iterrows():
            lines += [
                f"*{_escape(r['symbol'])}* — STRONG BUY",
                f"Score: {_escape(str(r['score']))}/100",
                f"Close: ₦{_escape(f\"{r['close']:.2f}\")}",
                f"Target: ₦{_escape(f\"{r['target_price']:.2f}\")}",
                f"Upside: *{_escape(f\"{r['target_return']:.2f}\")}%*",
                f"Sector: {_escape(str(r.get('sector','Unknown')))}",
                f"Reasons: {_escape(', '.join(r['reasons']))}",
                ""
            ]
    return "\n".join(lines)
