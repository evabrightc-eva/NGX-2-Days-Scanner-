import os
from datetime import date, timedelta
from pathlib import Path
import requests
import pandas as pd

BASE = "https://marketdataapiv3.ngxgroup.com/v3/api"

class NGXDataError(RuntimeError):
    pass

def _normalize(payload):
    if isinstance(payload, dict):
        for key in ("data", "Data", "result", "Result", "prices", "Prices"):
            if key in payload and isinstance(payload[key], list):
                payload = payload[key]
                break
    if not isinstance(payload, list):
        raise NGXDataError("Unexpected NGX API response format.")

    df = pd.DataFrame(payload)
    rename = {}
    aliases = {
        "date": ["date","Date","tradeDate","TradeDate"],
        "symbol": ["symbol","Symbol","security","Security","scrip","Scrip"],
        "open": ["open","Open","openPrice","OpenPrice"],
        "high": ["high","High","highPrice","HighPrice"],
        "low": ["low","Low","lowPrice","LowPrice"],
        "close": ["close","Close","closePrice","ClosePrice","currentPrice","CurrentPrice"],
        "volume": ["volume","Volume","volumeTraded","VolumeTraded"]
    }
    for target, names in aliases.items():
        for n in names:
            if n in df.columns:
                rename[n] = target
                break
    df = df.rename(columns=rename)
    required = ["date","symbol","open","high","low","close","volume"]
    missing = [x for x in required if x not in df.columns]
    if missing:
        raise NGXDataError(f"NGX response missing fields: {missing}")
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in required[2:]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["symbol"] = df["symbol"].astype(str).str.upper().str.strip()
    return df.dropna(subset=required).drop_duplicates(["date","symbol"])

def fetch_eod(token):
    url = f"{BASE}/price/pricesEOD.json"
    r = requests.get(url, params={"_t": token, "a": "EQUITY"}, timeout=30)
    r.raise_for_status()
    return _normalize(r.json())

def fetch_interday(token, symbol, start, end):
    url = f"{BASE}/price/interdayprices.json"
    r = requests.get(url, params={
        "s": symbol, "f": start.isoformat(), "t": end.isoformat(), "_t": token
    }, timeout=30)
    r.raise_for_status()
    return _normalize(r.json())

def load_csv_directory(directory):
    paths = sorted(Path(directory).glob("*.csv"))
    if not paths:
        return pd.DataFrame(columns=["date","symbol","open","high","low","close","volume"])
    frames = []
    for p in paths:
        try:
            d = pd.read_csv(p)
            d.columns = [c.strip().lower() for c in d.columns]
            frames.append(_normalize(d.to_dict("records")))
        except Exception as e:
            print(f"Skipping {p}: {e}")
    if not frames:
        return pd.DataFrame(columns=["date","symbol","open","high","low","close","volume"])
    return pd.concat(frames, ignore_index=True).drop_duplicates(["date","symbol"])

def get_prices(config):
    directory = config["data"]["price_dir"]
    token = os.getenv("NGX_API_TOKEN")
    if token:
        try:
            df = fetch_eod(token)
            Path(directory).mkdir(parents=True, exist_ok=True)
            today = date.today().isoformat()
            df.to_csv(Path(directory) / f"ngx_eod_{today}.csv", index=False)
            return df
        except Exception as e:
            print(f"NGX API unavailable; using cached CSV data: {e}")
    return load_csv_directory(directory)
