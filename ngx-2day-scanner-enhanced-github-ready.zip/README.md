# NGX 2-Day Strong-Buy Scanner

A GitHub Actions-ready Nigerian Exchange (NGX) equity scanner designed to identify **high-quality short-term setups with a 5%–10% two-trading-day target**.

It combines:
- completed daily OHLCV data
- momentum: 1d/5d/20d returns, RSI(14), MACD, moving averages
- volume and turnover behavior
- support/resistance and breakout checks
- fundamentals from a maintained CSV
- liquidity and risk filters
- a scoring engine with `STRONG BUY`, `BUY`, `WATCH`, and `NO SIGNAL`
- two-day forward outcome tracking and backtesting
- Markdown/CSV/JSON reports
- GitHub Actions schedules

## Important data note

For production use, supply a licensed/authorized NGX data feed. NGX states that historical/end-of-day data can be purchased and that market data is subject to its Market Data Agreement. The official NGX API documentation also describes authorized end-of-day and interday endpoints.

This project therefore uses an **official NGX API adapter when `NGX_API_TOKEN` is available**, plus a CSV fallback for testing/manual data imports. It does not scrape or bypass access controls.

## 1. Create the repository

Create a GitHub repository and copy this project into it.

Recommended repository name:

`ngx-2day-scanner`

## 2. Configure GitHub Secrets

Go to:

Settings → Secrets and variables → Actions

Add:

- `NGX_API_TOKEN` — your authorized NGX API token
- optionally `TELEGRAM_BOT_TOKEN`
- optionally `TELEGRAM_CHAT_ID`

If you don't have an NGX API token yet, the scanner can run against CSV files placed in `data/prices/`.

## 3. Local setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp config.example.yaml config.yaml
python -m scanner.run --mode primary
```

On Windows:

```powershell
.venv\Scripts\activate
pip install -r requirements.txt
python -m scanner.run --mode primary
```

## 4. Data formats

### Price CSV

Put one or more CSV files in `data/prices/`.

Required columns:

```text
date,symbol,open,high,low,close,volume
```

Example:

```text
2026-09-30,ZENITHBANK,65.00,67.00,64.50,66.50,12345678
```

### Fundamentals CSV

`data/fundamentals.csv`

Columns:

```text
symbol,market_cap,pe,pb,roe,revenue_growth,earnings_growth,gross_margin,net_margin,current_ratio,debt_to_equity,dividend_yield
```

Missing fundamental values are allowed. The scanner will reduce the fundamental score rather than invent data.

## 5. Production data flow

When `NGX_API_TOKEN` is configured:

1. Request the authorized NGX end-of-day/interday feed.
2. Normalize it to the internal OHLCV format.
3. Cache it under `data/prices/`.
4. Calculate indicators.
5. Join fundamentals.
6. Apply liquidity/risk filters.
7. Generate signals.
8. Save results under `reports/`.
9. Track previous signals.

The adapter is intentionally isolated in `scanner/data_ngx.py`, so another licensed NGX provider can be added without changing the signal engine.

## 6. Signal philosophy

A stock is not forced into Strong Buy.

Default Strong Buy requirements:

- score >= 78/100
- estimated two-day upside between 5% and 10%
- adequate liquidity
- no severe technical deterioration
- sufficient price history
- no extreme RSI penalty
- fundamental score not critically weak

The 5%–10% figure is a **screening target, not a promise or forecast guarantee**.

## 7. Scheduled GitHub Actions

The workflow runs:

- 08:00 WAT — pre-market confirmation
- 12:30 WAT — optional intraday/risk refresh
- 17:00 WAT — primary completed-close scan

GitHub Actions now supports timezone-aware schedules; this workflow explicitly uses `Africa/Lagos`.

Scheduled jobs can be delayed by GitHub infrastructure. The scanner therefore checks the actual local date/session before processing.

## 8. Reports

After each run:

```text
reports/latest.md
reports/latest.csv
reports/latest.json
reports/history.csv
reports/performance.csv
```

The Markdown report includes:

- market breadth
- candidates
- entry zone
- two-day target
- estimated upside
- score
- risk
- signal type
- reasons
- invalidated previous signals

## 9. Backtesting

Run:

```bash
python -m scanner.backtest
```

The backtest uses historical data and evaluates whether a signal's target or stop was reached during the next two trading sessions.

It reports:

- number of signals
- target-hit rate
- stop-hit rate
- average two-day return
- average winner
- average loser
- profit factor
- maximum drawdown proxy

Do not tune the thresholds against the same period used to report performance. Use walk-forward or out-of-sample testing.

## 10. Safety against bad signals

The scanner deliberately includes:

- minimum liquidity
- maximum spread proxy
- overextended RSI penalty
- resistance-distance check
- missing-data penalties
- stale-fundamental detection
- no-signal outcome
- signal expiry after two sessions

It does not automatically place trades.

## 11. Daily operating model

### Evening

The primary scan uses the completed NGX close and creates the next-session candidate list.

### Morning

The confirmation scan checks:

- latest available price
- overnight/news inputs if supplied
- whether technical conditions remain intact
- whether the expected target remains plausible

A previously generated Strong Buy can become:

`CONFIRMED`, `DOWNGRADED`, or `INVALIDATED`.

## 12. Improving results over time

Do not simply increase the number of BUY signals.

Monitor:

- precision of Strong Buy signals
- target-hit rate
- average winner/loser
- profit factor
- performance by sector
- performance by market-cap bucket
- performance during bullish/bearish breadth regimes

Only change thresholds after sufficient out-of-sample observations.



## Enhanced features

### Telegram

Create a Telegram bot with BotFather, obtain the bot token, add the bot to your chat/channel, and configure:

```text
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
```

The workflow sends the scanner's Strong Buy report after a successful run. If no Strong Buy qualifies, the default configuration does not send an alert.

### ASI regime and market breadth

The scanner calculates:

- advancers
- decliners
- unchanged
- advance breadth
- ASI 5-day return
- ASI vs 20-day moving average
- market regime: BULLISH / NEUTRAL / BEARISH

A Strong Buy is blocked by default in a BEARISH regime.

Put authorized index data in `data/indices.csv`:

```text
date,symbol,close
2026-09-30,ASI,123456.78
```

The production NGX adapter can be extended to retrieve the ASI directly from the NGX index-values endpoint.

### Sector and market-cap filters

Fundamentals now accept:

```text
sector
market_cap
```

The scanner can:

- reject stocks below minimum market cap
- optionally reject stocks above a maximum market cap
- calculate sector breadth/return
- reject weak sectors
- limit Strong Buy concentration to a maximum number per sector

### Walk-forward backtesting

Run:

```bash
python -m scanner.walkforward
```

The test walks through history in separate train/test windows rather than evaluating every historical observation as though the final model had been known in advance.

Outputs:

```text
reports/walkforward_trades.csv
reports/walkforward_summary.csv
```

Use this to assess whether the scanner remains useful across different market periods. Do not interpret a backtest as a guarantee of future performance.

### Telegram secrets

GitHub repository:

Settings → Secrets and variables → Actions

Add:

```text
NGX_API_TOKEN
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
```

Never put these values in `config.yaml` or commit them to Git.

### GitHub schedule

GitHub Actions supports IANA timezone-aware schedules, so the workflow uses `Africa/Lagos`. Scheduled workflows run from the default branch and can be delayed by GitHub infrastructure.

